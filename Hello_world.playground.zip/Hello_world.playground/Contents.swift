//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"
var a , b , c : Int
a = 10
b = 20
c = 3
print (a+b)

